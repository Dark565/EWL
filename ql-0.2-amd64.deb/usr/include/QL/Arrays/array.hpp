#pragma once

namespace ql {
    template<class T ,int size> struct Array {
        T x[size];
    };
}