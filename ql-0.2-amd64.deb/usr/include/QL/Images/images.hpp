#pragma once

#include <string>
namespace ql {
    std::string readFormat(const char* format);
}