#pragma once

namespace ql {
    
    class Socket {

    }

}